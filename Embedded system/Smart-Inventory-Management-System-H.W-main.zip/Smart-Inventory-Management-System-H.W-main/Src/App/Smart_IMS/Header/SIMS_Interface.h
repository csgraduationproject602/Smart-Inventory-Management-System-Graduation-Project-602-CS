/*
 * ============================================================================================================*
 * Author      : Alaa Emad
 * Module name : Smart Inventory Management System
 * File name   : SIMS_Interface.h
 * Version     : V1.0.0
 * Date        : Feb 12 2025
 * Description : Prototypes and other files are included here
 ============================================================================================================
*/

#ifndef SRC_APP_SMART_IMS_HEADER_SIMS_INTERFACE_H_
#define SRC_APP_SMART_IMS_HEADER_SIMS_INTERFACE_H_

/*Include the required user libraries for the project from the user libraries*/
#include "../../../MCAL/DIO/Header/DIO_Interface.h"
#include "../../../MCAL/USART/Header/USART_Interface.h"
#include "../../../MCAL/GIE/Header/GIE_Interface.h"
#include "../../../MCAL/Timer0/Header/Timer0_Interface.h"
#include "../../../MCAL/EXTI/Header/EXTI_Interface.h"
#include "../../../HAL/IR_Sensor/Header/IR_Interface.h"
#include "../../../HAL/Button/Header/Button_Interface.h"
#include "../../../HAL/RGB_LED/Header/RGBLED_Interface.h"
#include "../../../HAL/LCD/Header/LCD_Interface.h"
#include "../../../HAL/Buzzer/Header/Buzzer_Interface.h"

/*Include the required user libraries for the project from the system libraries*/
#include <util/delay.h>

/*Prototyping the SystemInit Function*/
void SystemInit();

/*Prototyping the SystemRunning Function*/
void SystemRunning();

/*Prototyping the Display_System_Information Function*/
void Display_System_Information();

/*Prototyping the vector_1 ISR Function*/
void __vector_1(void) __attribute__((signal));

#endif /* SRC_APP_SMART_IMS_HEADER_SIMS_INTERFACE_H_ */
