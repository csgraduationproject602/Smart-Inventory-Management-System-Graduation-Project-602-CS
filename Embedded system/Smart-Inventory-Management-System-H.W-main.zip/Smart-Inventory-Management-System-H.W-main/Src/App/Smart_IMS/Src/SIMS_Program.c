/*
 * ============================================================================================================*
 * Author      : Alaa Emad
 * Module name : Smart Inventory Management System
 * File name   : SIMS_Program.c
 * Version     : V1.0.0
 * Date        : Feb 12 2025
 * Description : The core of the project provided here
 ============================================================================================================
*/

#include "../Header/SIMS_Interface.h"

/*Creating static global variable to hold the shelf state*/
static uint_8 ShelfState = 0;

/*Implementation of the SystemInit Function*/
void SystemInit()
{
	/*USART TX Pin*/
	DIO_SelectDirectionForPin(GroupD,Pin1,Output);

	/*Initialize USART*/
	USART_Init();

	/*Initialize LCD*/
	LCD_Init8BitMode();

	/*Initialize The RGB LEDs*/
	RGB_LED_Init(LED1);
	RGB_LED_Init(LED2);
	RGB_LED_Init(LED3);
	RGB_LED_Init(LED4);
	RGB_LED_Init(LED5);
	RGB_LED_Init(LED6);

	/*Initialize IR Sensors*/
	IR_SensorInit();

	/*Initialize Buzzer*/
	BuzzerInit();

	/*Initialize Button*/
	ButtonInit(Button1);

	/*Enable General Interrupt*/
	GIE_Enable();

	/*Initialize EXTI0 to detect FallingEdge*/
	EXTI0_Init(FallingEdge);
}

/*Implementation of the SystemRunning Function*/
void SystemRunning()
{
	/*Welcome Message*/
	LCD_GoToXY(0,5);
	LCD_DisplayString("Welcome");
	LCD_GoToXY(1,0);
	LCD_DisplayString("To Warehouse  A");
	_delay_ms(1500);
	LCD_SendDataCommand8BitMode(0x01);
	LCD_GoToXY(0,0);
	LCD_DisplayString("Hold the Button");
	LCD_GoToXY(1,0);
	LCD_DisplayString("To hold screen");
	_delay_ms(1500);

	/*Start Timer 0 Counting to display the system information*/
	T0_CallBackFunctionNormalMode(Display_System_Information);
	T0_NormalModeInit();

	/*Creating 6 Variables to store the value of the IR Sensor*/
	uint_8 IR1Value = 0xFF;
	uint_8 IR2Value = 0xFF;
	uint_8 IR3Value = 0xFF;
	uint_8 IR4Value = 0xFF;
	uint_8 IR5Value = 0xFF;
	uint_8 IR6Value = 0xFF;

	/*Creating static local variable to hold the number of empty shelves*/
	static uint_8 NumberOfEmptyShelfs = 0;

	/*Creating counter for loops*/
	uint_8 Counter = 0;

	while(1)
	{
		/*Reinitialize the Number of empty shelves with 6*/
		NumberOfEmptyShelfs = 6;

		/*Read IR Sensor Values*/
		IR1Value = ReadIR_SensorValue(IR_1);
		IR2Value = ReadIR_SensorValue(IR_2);
		IR3Value = ReadIR_SensorValue(IR_3);
		IR4Value = ReadIR_SensorValue(IR_4);
		IR5Value = ReadIR_SensorValue(IR_5);
		IR6Value = ReadIR_SensorValue(IR_6);

		/*Check Values*/
		if(IR1Value == 1)
		{
			/*Nothing Detected*/
			RGB_LED_ON(LED1,GREEN);
			/*Reset buzzer counter*/
			Counter = 0;
			ClrBit(ShelfState,0);
		}
		else if(IR1Value == 0)
		{
			/*Shipment Detected*/
			RGB_LED_ON(LED1,RED);
			NumberOfEmptyShelfs--;
			SetBit(ShelfState,0);
		}
		if(IR2Value == 1)
		{
			/*Nothing Detected*/
			RGB_LED_ON(LED2,GREEN);
			/*Reset buzzer counter*/
			Counter = 0;
			ClrBit(ShelfState,1);
		}
		else if(IR2Value == 0)
		{
			/*Shipment Detected*/
			RGB_LED_ON(LED2,RED);
			NumberOfEmptyShelfs--;
			SetBit(ShelfState,1);
		}
		if(IR3Value == 1)
		{
			/*Nothing Detected*/
			RGB_LED_ON(LED3,GREEN);
			/*Reset buzzer counter*/
			Counter = 0;
			ClrBit(ShelfState,2);
		}
		else if(IR3Value == 0)
		{
			/*Shipment Detected*/
			RGB_LED_ON(LED3,RED);
			NumberOfEmptyShelfs--;
			SetBit(ShelfState,2);
		}
		if(IR4Value == 1)
		{
			/*Nothing Detected*/
			RGB_LED_ON(LED4,GREEN);
			/*Reset buzzer counter*/
			Counter = 0;
			ClrBit(ShelfState,3);
		}
		else if(IR4Value == 0)
		{
			/*Shipment Detected*/
			RGB_LED_ON(LED4,RED);
			NumberOfEmptyShelfs--;
			SetBit(ShelfState,3);
		}
		if(IR5Value == 1)
		{
			/*Nothing Detected*/
			RGB_LED_ON(LED5,GREEN);
			/*Reset buzzer counter*/
			Counter = 0;
			ClrBit(ShelfState,4);
		}
		else if(IR5Value == 0)
		{
			/*Shipment Detected*/
			RGB_LED_ON(LED5,RED);
			NumberOfEmptyShelfs--;
			SetBit(ShelfState,4);
		}
		if(IR6Value == 1)
		{
			/*Nothing Detected*/
			RGB_LED_ON(LED6,GREEN);
			/*Reset buzzer counter*/
			Counter = 0;
			ClrBit(ShelfState,5);
		}
		else if(IR6Value == 0)
		{
			/*Shipment Detected*/
			RGB_LED_ON(LED6,RED);
			NumberOfEmptyShelfs--;
			SetBit(ShelfState,5);
		}
		if(NumberOfEmptyShelfs == 0 && Counter < 5)
		{
			/*Toggle buzzer to inform that the warehouse is full*/
			BuzzerOn();
			_delay_ms(100);
			BuzzerOff();
			_delay_ms(100);
			if(Counter == 0)
			{
				/*Print on the LCD that the warehouse is full*/
				T0_DisableTimer();
				LCD_SendDataCommand8BitMode(0x01);
				LCD_GoToXY(0,0);
				LCD_DisplayString("YOU CAN'T ADD");
				LCD_GoToXY(1,0);
				LCD_DisplayString("MORE SHIPMENTS !");
				T0_NormalModeInit();
			}
			Counter++;
		}
		/*Send the number of empty shelves to the NodeMCU ESP8266 via USART*/
		USART_TxChar(NumberOfEmptyShelfs);
	}
}

/*Implementation of the Display_System_Information Function*/
void Display_System_Information()
{
	/*Creating some variables*/
	static uint_8 Counter = 0;
	static uint_8 EmptyShelves = 0;
	static uint_8 FullShelves = 0;
	static uint_8 state = 0;
	/*First data that will appear on the screen*/
	if(state == 0)
	{
		LCD_SendDataCommand8BitMode(0x01);
		LCD_GoToXY(0,0);
		LCD_DisplayString("Number Of Empty");
		LCD_GoToXY(1,0);
		LCD_DisplayString("Shelves equal ");
		LCD_GoToXY(1,14);
		/*Calculate the number of empty shelves*/
		for(Counter = 0; Counter < 6; Counter++)
		{
			if(GetBit(ShelfState,Counter) == 0)
			{
				EmptyShelves++;
			}
		}
		LCD_SendDataDisplay8bitMode(EmptyShelves + 0x30);
		EmptyShelves = 0;
		state = 1;
	}
	/*Second data that will appear on the screen*/
	else if(state == 1)
	{
		LCD_SendDataCommand8BitMode(0x01);
		LCD_GoToXY(0,0);
		LCD_DisplayString("Number Of Full");
		LCD_GoToXY(1,0);
		LCD_DisplayString("Shelves equal ");
		LCD_GoToXY(1,14);
		/*Calculate the number of full shelves*/
		for(Counter = 0; Counter < 6; Counter++)
		{
			if(GetBit(ShelfState,Counter) == 1)
			{
				FullShelves++;
			}
		}
		LCD_SendDataDisplay8bitMode(FullShelves + 0x30);
		FullShelves = 0;
		state = 2;
	}
	/*Third data that will appear on the screen*/
	else if(state == 2)
	{
		LCD_SendDataCommand8BitMode(0x01);
		LCD_GoToXY(0,0);
		LCD_DisplayString("Empty Shelves ID");
		LCD_GoToXY(1,0);
		/*Calculate the empty shelves ID*/
		for(Counter = 0; Counter < 6; Counter++)
		{
			if(GetBit(ShelfState,Counter) == 0)
			{
				LCD_SendDataDisplay8bitMode((Counter + 1) + 0x30);
				LCD_SendDataDisplay8bitMode(' ');
			}
		}
		if(ShelfState >= 63)
		{
			LCD_DisplayString("NOTHIG");
		}
		state = 3;
	}
	/*Forth data that will appear on the screen*/
	else if(state == 3)
	{
		LCD_SendDataCommand8BitMode(0x01);
		LCD_GoToXY(0,0);
		LCD_DisplayString("Full Shelves ID:");
		LCD_GoToXY(1,0);
		/*Calculate the full shelves ID*/
		for(Counter = 0; Counter < 6; Counter++)
		{
			if(GetBit(ShelfState,Counter) == 1)
			{
				LCD_SendDataDisplay8bitMode((Counter + 1) + 0x30);
				LCD_SendDataDisplay8bitMode(' ');
			}
		}
		if(ShelfState == 0)
		{
			LCD_DisplayString("NOTHIG");
		}
		state = 0;
	}
}

/*Implementation of the __vector_1 function*/
void __vector_1(void)
{
	static uint_8 state = 0;
	if(state == 0)
	{
		/*Disable the timer to hold on a screen*/
		T0_DisableTimer();
		/*Switch sensing type to RisingEdge*/
		EXTI0_Init(RisingEdge);
		state = 1;
	}
	else if(state == 1)
	{
		/*Enable the timer to switch the screen*/
		T0_NormalModeInit();
		/*Switch sensing type to FallingEdge*/
		EXTI0_Init(FallingEdge);
		state = 0;
	}
}
