/*
 * ============================================================================================================*
 * Author      : Alaa Emad
 * Module name : Button
 * File name   : Button_Config.h
 * Version     : V1.0.0
 * Date        : Jan 25 2025
 * Description : Adding some definitions can be modified
 ============================================================================================================
*/

#ifndef SRC_HAL_BUTTON_HEADER_BUTTON_CONFIG_H_
#define SRC_HAL_BUTTON_HEADER_BUTTON_CONFIG_H_

#define Button1Group    GroupD
#define Button1Pin      Pin2

#define Button2Group    GroupB
#define Button2Pin      Pin1

#endif /* SRC_HAL_BUTTON_HEADER_BUTTON_CONFIG_H_ */
