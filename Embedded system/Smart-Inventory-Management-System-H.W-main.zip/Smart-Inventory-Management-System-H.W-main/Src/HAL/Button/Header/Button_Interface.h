/*
 * ============================================================================================================*
 * Author      : Alaa Emad
 * Module name : Button
 * File name   : Button_Interface.h
 * Version     : V1.0.0
 * Date        : Jan 25 2025
 * Description : Prototypes and other files are included here
 ============================================================================================================
*/

#ifndef SRC_HAL_BUTTON_HEADER_BUTTON_INTERFACE_H_
#define SRC_HAL_BUTTON_HEADER_BUTTON_INTERFACE_H_

/*Include the user libraries from the lib file*/
#include "../../../Lib/BitMath.h"
#include "../../../Lib/Definition.h"
#include "../../../Lib/StdType.h"

#include "Button_Private.h"
#include "Button_Config.h"
#include "Button_Register.h"

void ButtonInit(uint_8 ButtonNo);
void ButtonState(uint_8 ButtonNo , uint_8 * State);

#endif /* SRC_HAL_BUTTON_HEADER_BUTTON_INTERFACE_H_ */
