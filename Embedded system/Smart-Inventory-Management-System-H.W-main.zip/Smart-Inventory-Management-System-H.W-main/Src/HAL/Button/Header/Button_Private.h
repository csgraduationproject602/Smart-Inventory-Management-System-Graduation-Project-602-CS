/*
 * ============================================================================================================*
 * Author      : Alaa Emad
 * Module name : Button
 * File name   : Button_Private.h
 * Version     : V1.0.0
 * Date        : Jan 25 2025
 * Description : Adding some definitions can't be modified
 ============================================================================================================
*/

#ifndef SRC_HAL_BUTTON_HEADER_BUTTON_PRIVATE_H_
#define SRC_HAL_BUTTON_HEADER_BUTTON_PRIVATE_H_


#define NumberOfButtons 2

#define Button1    1
#define Button2    2

#endif /* SRC_HAL_BUTTON_HEADER_BUTTON_PRIVATE_H_ */
