/*
 * ============================================================================================================*
 * Author      : Alaa Emad
 * Module name : Button
 * File name   : Button_Register.h
 * Version     : V1.0.0
 * Date        : Jan 25 2025
 * Description : Definition of the registers and there address
 ============================================================================================================
*/

#ifndef SRC_HAL_BUTTON_HEADER_BUTTON_REGISTER_H_
#define SRC_HAL_BUTTON_HEADER_BUTTON_REGISTER_H_



#endif /* SRC_HAL_BUTTON_HEADER_BUTTON_REGISTER_H_ */
