/*
 * ============================================================================================================*
 * Author      : Alaa Emad
 * Module name : Button
 * File name   : Button_Program.c
 * Version     : V1.0.0
 * Date        : Jan 25 2025
 * Description : Implementation of the functions are here
 ============================================================================================================
*/

/*Including the user libraries required*/
#include "../../../MCAL/DIO/Header/DIO_Interface.h"
#include "../Header/Button_Interface.h"

void ButtonInit(uint_8 ButtonNo)
{
      switch(ButtonNo)
      {
	case Button1: DIO_ControlInternalPullUpForPin(Button1Group,Button1Pin,Enable);break;
	case Button2: DIO_ControlInternalPullUpForPin(Button2Group,Button2Pin,Enable);break;
	default: /*Error State*/ break;
      }
}

void ButtonState(uint_8 ButtonNo , uint_8 * State)
{
      if(State != NULL)
	{
	  switch(ButtonNo)
	  {
	    case Button1: DIO_ReadInputValueForPin(Button1Group,Button1Pin,State);break;
	    case Button2: DIO_ReadInputValueForPin(Button2Group,Button2Pin,State);break;
	    default: /*Error State*/ break;
	  }
	}
      else
	{

	}
}
