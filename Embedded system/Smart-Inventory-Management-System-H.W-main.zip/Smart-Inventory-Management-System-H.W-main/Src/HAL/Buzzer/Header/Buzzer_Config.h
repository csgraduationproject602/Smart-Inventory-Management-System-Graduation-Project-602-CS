/*
 * ============================================================================================================*
 * Author      : Martina Safwat Lito
 * Module name : Buzzer
 * File name   : Buzzer_Config.h
 * Version     : V1.0.0
 * Date        : Dec 25 2024
 * Description : Adding some definitions can be modified
 ============================================================================================================
*/

#ifndef SRC_HAL_BUZZER_HEADER_BUZZER_CONFIG_H_
#define SRC_HAL_BUZZER_HEADER_BUZZER_CONFIG_H_

/*Define the Buzzer configs (Group / Pin)*/
#define BuzzerGroup	GroupA
#define BuzzerPin	Pin7

#endif /* SRC_HAL_BUZZER_HEADER_BUZZER_CONFIG_H_ */
