/*
 * ============================================================================================================*
 * Author      : Martina Safwat Lito
 * Module name : Buzzer
 * File name   : Buzzer_Interface.h
 * Version     : V1.0.0
 * Date        : Dec 25 2024
 * Description : Prototypes and other files are included here
 ============================================================================================================
*/

#ifndef SRC_HAL_BUZZER_HEADER_BUZZER_INTERFACE_H_
#define SRC_HAL_BUZZER_HEADER_BUZZER_INTERFACE_H_

/*Include the user libraries from the Lib folder*/
#include "../../../Lib/BitMath.h"
#include "../../../Lib/Definition.h"
#include "../../../Lib/StdType.h"

/*Include the other Buzzer files*/
#include "Buzzer_Config.h"
#include "Buzzer_Private.h"
#include "Buzzer_Register.h"

/*Prototype of the Buzzer functions*/
void BuzzerInit();
void BuzzerOn();
void BuzzerOff();
void BuzzerToggle();

#endif /* SRC_HAL_BUZZER_HEADER_BUZZER_INTERFACE_H_ */
