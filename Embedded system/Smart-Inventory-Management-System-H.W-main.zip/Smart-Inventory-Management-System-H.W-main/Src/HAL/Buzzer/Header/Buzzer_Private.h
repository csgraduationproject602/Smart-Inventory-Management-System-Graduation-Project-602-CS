/*
 * ============================================================================================================*
 * Author      : Martina Safwat Lito
 * Module name : Buzzer
 * File name   : Buzzer_Private.h
 * Version     : V1.0.0
 * Date        : Dec 25 2024
 * Description : Adding some definitions can't be modified
 ============================================================================================================
*/

#ifndef SRC_HAL_BUZZER_HEADER_BUZZER_PRIVATE_H_
#define SRC_HAL_BUZZER_HEADER_BUZZER_PRIVATE_H_



#endif /* SRC_HAL_BUZZER_HEADER_BUZZER_PRIVATE_H_ */
