/*
 * ============================================================================================================*
 * Author      : Martina Safwat Lito
 * Module name : Buzzer
 * File name   : Buzzer_Register.h
 * Version     : V1.0.0
 * Date        : Dec 25 2024
 * Description : Definition of the registers and there address
 ============================================================================================================
*/

#ifndef SRC_HAL_BUZZER_HEADER_BUZZER_REGISTER_H_
#define SRC_HAL_BUZZER_HEADER_BUZZER_REGISTER_H_



#endif /* SRC_HAL_BUZZER_HEADER_BUZZER_REGISTER_H_ */
