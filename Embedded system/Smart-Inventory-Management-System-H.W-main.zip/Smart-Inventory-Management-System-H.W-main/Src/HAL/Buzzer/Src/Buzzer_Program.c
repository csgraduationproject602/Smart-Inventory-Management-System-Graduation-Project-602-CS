/*
 * ============================================================================================================*
 * Author      : Martina Safwat Lito
 * Module name : Buzzer
 * File name   : Buzzer_Program.c
 * Version     : V1.0.0
 * Date        : Dec 25 2024
 * Description : Implementation of the functions are here
 ============================================================================================================
*/

/*Include the DIO Driver and Buzzer_Interface.h file*/
#include "../../../MCAL/DIO/Header/DIO_Interface.h"
#include "../Header/Buzzer_Interface.h"

/*Implementation of the BuzzerInit function*/
void BuzzerInit()
{

    DIO_SelectDirectionForPin(BuzzerGroup,BuzzerPin,Output);
}

/*Implementation of the BuzzerOn function*/
void BuzzerOn()
{
    DIO_SelectOutputValueForPin(BuzzerGroup,BuzzerPin,High);
}

/*Implementation of the BuzzerOff function*/
void BuzzerOff()
{
    DIO_SelectOutputValueForPin(BuzzerGroup,BuzzerPin,Low);
}

/*Implementation of the BuzzerToggle function*/
void BuzzerToggle()
{

   DIO_ToggelValueForPin(BuzzerGroup,BuzzerPin);

}
