/*
 * ============================================================================================================*
 * Author      : Alaa Emad
 * Module name : IR_Sensor
 * File name   : IR_Config.h
 * Version     : V1.0.0
 * Date        : Dec 24 2024
 * Description : Adding some definitions can be modified
 ============================================================================================================
*/

#ifndef SRC_HAL_IR_SENSOR_HEADER_IR_CONFIG_H_
#define SRC_HAL_IR_SENSOR_HEADER_IR_CONFIG_H_

/*Define the number of IR sensors needed in the project*/
#define NumberOfIRSensors	6

/*Define a Specific Group for the IR Sensors*/
#define IRSensorsGroup	GroupB

#endif /* SRC_HAL_IR_SENSOR_HEADER_IR_CONFIG_H_ */
