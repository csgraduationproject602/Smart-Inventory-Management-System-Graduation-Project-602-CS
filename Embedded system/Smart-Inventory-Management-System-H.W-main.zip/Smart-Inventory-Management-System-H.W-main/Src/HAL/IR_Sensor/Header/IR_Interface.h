/*
 * ============================================================================================================*
 * Author      : Alaa Emad
 * Module name : IR_Sensor
 * File name   : IR_Interface.h
 * Version     : V1.0.0
 * Date        : Dec 24 2024
 * Description : Prototypes and other files are included here
 ============================================================================================================
*/

#ifndef SRC_HAL_IR_SENSOR_HEADER_IR_INTERFACE_H_
#define SRC_HAL_IR_SENSOR_HEADER_IR_INTERFACE_H_

/*Include the user libraries from the Lib folder*/
#include "../../../Lib/BitMath.h"
#include "../../../Lib/Definition.h"
#include "../../../Lib/StdType.h"

/*Include the other IR sensor files*/
#include "IR_Config.h"
#include "IR_Private.h"
#include "IR_Register.h"

/*Prototype of the IR functions*/
void IR_SensorInit();
uint_8 ReadIR_SensorValue(uint_8 IR_Number);

#endif /* SRC_HAL_IR_SENSOR_HEADER_IR_INTERFACE_H_ */
