/*
 * ============================================================================================================*
 * Author      : Alaa Emad
 * Module name : IR_Sensor
 * File name   : IR_Private.h
 * Version     : V1.0.0
 * Date        : Dec 24 2024
 * Description : Adding some definitions can't be modified
 ============================================================================================================
*/

#ifndef SRC_HAL_IR_SENSOR_HEADER_IR_PRIVATE_H_
#define SRC_HAL_IR_SENSOR_HEADER_IR_PRIVATE_H_

/*Define each IR sensor with a unique number*/
#define IR_1	0
#define IR_2	1
#define IR_3	2
#define IR_4	3
#define IR_5	4
#define IR_6	5

#endif /* SRC_HAL_IR_SENSOR_HEADER_IR_PRIVATE_H_ */
