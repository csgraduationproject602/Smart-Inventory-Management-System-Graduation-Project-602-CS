/*
 * ============================================================================================================*
 * Author      : Alaa Emad
 * Module name : IR_Sensor
 * File name   : IR_Register.h
 * Version     : V1.0.0
 * Date        : Dec 24 2024
 * Description : Definition of the registers and there address
 ============================================================================================================
*/

#ifndef SRC_HAL_IR_SENSOR_HEADER_IR_REGISTER_H_
#define SRC_HAL_IR_SENSOR_HEADER_IR_REGISTER_H_



#endif /* SRC_HAL_IR_SENSOR_HEADER_IR_REGISTER_H_ */
