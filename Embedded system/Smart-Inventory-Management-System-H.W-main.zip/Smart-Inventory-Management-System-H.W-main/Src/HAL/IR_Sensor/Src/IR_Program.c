/*
 * ============================================================================================================*
 * Author      : Alaa Emad
 * Module name : IR_Sensor
 * File name   : IR_Program.c
 * Version     : V1.0.0
 * Date        : Dec 24 2024
 * Description : Implementation of the functions are here
 ============================================================================================================
*/

/*Include the DIO Driver and IR_Interface.h file*/
#include "../../../MCAL/DIO/Header/DIO_Interface.h"
#include "../../IR_Sensor/Header/IR_Interface.h"

/*Implementation of the IR_SensorInit function*/
void IR_SensorInit()
{
      DIO_ControlInternalPullUpForPin(IRSensorsGroup,IR_1,Enable);
      DIO_ControlInternalPullUpForPin(IRSensorsGroup,IR_2,Enable);
      DIO_ControlInternalPullUpForPin(IRSensorsGroup,IR_3,Enable);
      DIO_ControlInternalPullUpForPin(IRSensorsGroup,IR_4,Enable);
      DIO_ControlInternalPullUpForPin(IRSensorsGroup,IR_5,Enable);
      DIO_ControlInternalPullUpForPin(IRSensorsGroup,IR_6,Enable);
}

/*Implementation of the ReadIR_SensorValue function*/
uint_8 ReadIR_SensorValue(uint_8 IR_Number)
{
  uint_8 IRSensorValue = 0;
      if(IR_Number >= IR_1 && IR_Number <= IR_6)
	{
	  DIO_ReadInputValueForPin(IRSensorsGroup,IR_Number,&IRSensorValue);
	}
      else
	{
	  IRSensorValue = 0xFF;
	}
  return IRSensorValue;
}
