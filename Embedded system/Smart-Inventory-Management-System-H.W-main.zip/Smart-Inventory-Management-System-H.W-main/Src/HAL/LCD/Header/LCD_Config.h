/*
 * ============================================================================================================*
 * Author      : Martina Safwat Lito
 * Module name : LCD
 * File name   : LCD_Config.h
 * Version     : V1.0.0
 * Date        : Jan 5 2025
 * Description : Contains configuration definitions for setting up microcontroller pins and ports
 ============================================================================================================
*/

#ifndef HAL_LCD_HEADER_LCD_CONFIG_H_
#define HAL_LCD_HEADER_LCD_CONFIG_H_

#define LcdDataGroup GroupC

#define LcdControl_Group GroupA

#define LcdControl_RS Pin0
#define LcdControl_RW Pin1
#define LcdControl_E Pin2

#endif /* HAL_LCD_HEADER_LCD_CONFIG_H_ */
