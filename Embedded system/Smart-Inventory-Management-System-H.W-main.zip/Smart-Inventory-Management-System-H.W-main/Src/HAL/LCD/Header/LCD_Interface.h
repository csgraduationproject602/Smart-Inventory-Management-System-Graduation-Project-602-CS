/*
 * ============================================================================================================*
 * Author      : Martina Safwat Lito
 * Module name : LCD
 * File name   : LCD_Interface.h
 * Version     : V1.0.2
 * Date        : Jan 5 2025
 * Description : Contains function prototypes for configuring and controlling microcontroller pins and ports
 ============================================================================================================
*/

#ifndef HAL_LCD_HEADER_LCD_INTERFACE_H_
#define HAL_LCD_HEADER_LCD_INTERFACE_H_

#include "../../../Lib/BitMath.h"
#include "../../../Lib/Definition.h"
#include "../../../Lib/StdType.h"

#include "LCD_Private.h"
#include "LCD_Config.h"
#include "LCD_Register.h"

/*For 8 bit mode*/
void LCD_SendDataDisplay8bitMode(uint_8 Data);
void LCD_SendDataCommand8BitMode(uint_8 Command);
void LCD_Init8BitMode();

/*General*/
void LCD_DisplayString(uint_8 * String);
void LCD_GoToXY(uint_8 XPOS, uint_8 YPOS);
void LCD_ShiftOperation(uint_8 ShiftDirection);
void LCD_StoreSpecialChar(uint_8  BlockNo , uint_8 * SpecialArray);

#endif /* HAL_LCD_HEADER_LCD_INTERFACE_H_ */
