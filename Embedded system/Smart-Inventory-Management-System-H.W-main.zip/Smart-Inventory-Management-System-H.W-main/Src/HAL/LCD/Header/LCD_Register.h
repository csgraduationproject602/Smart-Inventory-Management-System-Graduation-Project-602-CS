/*
 * ============================================================================================================*
 * Author      : Martina Safwat Lito
 * Module name : LCD
 * File name   : LCD_Register.h
 * Version     : V1.0.0
 * Date        : Jan 5 2025
 * Description : Define of each register and its address of LCD included in this file
 ============================================================================================================
*/

#ifndef HAL_LCD_HEADER_LCD_REGISTER_H_
#define HAL_LCD_HEADER_LCD_REGISTER_H_



#endif /* HAL_LCD_HEADER_LCD_REGISTER_H_ */
