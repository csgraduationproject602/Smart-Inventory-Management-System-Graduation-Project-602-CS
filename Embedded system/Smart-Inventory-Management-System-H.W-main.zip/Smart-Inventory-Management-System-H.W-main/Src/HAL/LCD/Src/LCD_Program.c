/*
 * ============================================================================================================*
 * Author      : Martina Safwat Lito
 * Module name : LCD
 * File name   : LCD_Program.c
 * Version     : V1.0.0
 * Date        : Jan 5 2025
 * Description : Implementation of the LCD API's here
 ============================================================================================================
*/

#include <util/delay.h>
#include "../../../MCAL/DIO/Header/DIO_Interface.h"
#include "../Header/LCD_Interface.h"

static uint_8 LCDMode = 0;

void LCD_SendDataDisplay8bitMode(uint_8 Data)
{
	/*RS*/
	DIO_SelectOutputValueForPin(LcdControl_Group, LcdControl_RS, High);
	/*RW*/
	DIO_SelectOutputValueForPin(LcdControl_Group, LcdControl_RW, Low);
	/*Enable E*/
	DIO_SelectOutputValueForPin(LcdControl_Group, LcdControl_E, High);
	/*Data*/
	DIO_SelectOutputValueForGroup(LcdDataGroup, Data);
	/*Disable E*/
	DIO_SelectOutputValueForPin(LcdControl_Group, LcdControl_E, Low);
}

void LCD_SendDataCommand8BitMode(uint_8 Command)
{
	/*RS*/
	DIO_SelectOutputValueForPin(LcdControl_Group, LcdControl_RS, Low);
	/*RW*/
	DIO_SelectOutputValueForPin(LcdControl_Group, LcdControl_RW, Low);
	/*Enable E*/
	DIO_SelectOutputValueForPin(LcdControl_Group, LcdControl_E, High);
	/*Data*/
	DIO_SelectOutputValueForGroup(LcdDataGroup, Command);
	/*Disable E*/
	DIO_SelectOutputValueForPin(LcdControl_Group, LcdControl_E, Low);
	_delay_ms(2);
}

void LCD_Init8BitMode()
{
	/*Select the direction for Pin and Data Group*/
	DIO_SelectDirectionForPin(LcdControl_Group, LcdControl_RS, Output);
	DIO_SelectDirectionForPin(LcdControl_Group, LcdControl_RW, Output);
	DIO_SelectDirectionForPin(LcdControl_Group, LcdControl_E, Output);
	DIO_SelectDirectionForGroup(LcdDataGroup, 0xFF);
	/*-----------------------------------------*/
	/*Initi*/
	LCDMode = _8BitMode;
	_delay_ms(35);
	/*Function Set*/
	LCD_SendDataCommand8BitMode(0x38);
	//_delay_ms(2);
	/*Display ON/OFF*/
	LCD_SendDataCommand8BitMode(0x0C);
	//_delay_ms(2);
	/*Clear Display*/
	LCD_SendDataCommand8BitMode(0x01);
	//_delay_ms(2);
	/*Entry Mode*/
	LCD_SendDataCommand8BitMode(0x06);
	//_delay_ms(2);
}

void LCD_DisplayString(uint_8 * String)
{
  uint_8 Count = 0;
	if(String != NULL)
	{
		while(String[Count] != '\0')
		{
			if(LCDMode == _8BitMode)
			{
				LCD_SendDataDisplay8bitMode(String[Count]);
				Count++;
			}
		}
	}
}

void LCD_GoToXY(uint_8 XPOS, uint_8 YPOS)
{
	//Cal DDRAM Address
	//X Row 'Line'
	//Y Column 'Digit'
  uint_8 DDRAM_Adderss = 0;
	switch(XPOS)
	{
	case 0 : DDRAM_Adderss = 0x00 + YPOS; break;
	case 1 : DDRAM_Adderss = 0x40 + YPOS; break;
	}
	if(LCDMode == _8BitMode)
	{
		LCD_SendDataCommand8BitMode(0x80 + DDRAM_Adderss);
	}
}

void LCD_ShiftOperation(uint_8 ShiftDirection)
{
  uint_8 counter = 0;
	if(LCDMode == _8BitMode)
	{
		for(counter = 0; counter <= 15; counter++)
		{
			LCD_SendDataCommand8BitMode(ShiftDirection);
			_delay_ms(300);
		}
	}
}

void LCD_StoreSpecialChar(uint_8  BlockNo , uint_8 * SpecialArray)
{
	if(SpecialArray != NULL)
	{
	    uint_8 CGRAMAddress = BlockNo * 8;
	    uint_8 counter = 0;
		if(LCDMode == _8BitMode)
		{
			LCD_SendDataCommand8BitMode(0x40 | CGRAMAddress);
			for(counter = 0; counter < 8; counter++)
			{
				LCD_SendDataDisplay8bitMode(SpecialArray[counter]);
			}
		}
	}
}
