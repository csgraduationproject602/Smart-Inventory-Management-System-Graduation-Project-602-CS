/*
 * ============================================================================================================*
 * Author      : Alaa Emad
 * Module name : RGB_LED
 * File name   : RGBLED_Config.h
 * Version     : V1.0.0
 * Date        : Feb 12 2025
 * Description : Adding some definitions can be modified
 ============================================================================================================
*/

#ifndef SRC_HAL_RGB_LED_HEADER_RGBLED_CONFIG_H_
#define SRC_HAL_RGB_LED_HEADER_RGBLED_CONFIG_H_

/*RGB LED 1*/
#define RGB_LED1_Group	GroupA
#define RGB_LED1_RED	Pin3
#define RGB_LED1_Green	Pin4
/*----------------------------------------------------*/
/*RGB LED 2*/
#define RGB_LED2_Group	GroupA
#define RGB_LED2_RED	Pin5
#define RGB_LED2_Green	Pin6
/*----------------------------------------------------*/
/*RGB LED 3*/
#define RGB_LED3_Group	GroupB
#define RGB_LED3_RED	Pin6
#define RGB_LED3_Green	Pin7
/*----------------------------------------------------*/
/*RGB LED 4*/
#define RGB_LED4_Group	GroupD
#define RGB_LED4_RED	Pin0
#define RGB_LED4_Green	Pin3
/*----------------------------------------------------*/
/*RGB LED 5*/
#define RGB_LED5_Group	GroupD
#define RGB_LED5_RED	Pin4
#define RGB_LED5_Green	Pin5
/*----------------------------------------------------*/
/*RGB LED 6*/
#define RGB_LED6_Group	GroupD
#define RGB_LED6_RED	Pin6
#define RGB_LED6_Green	Pin7
/*----------------------------------------------------*/

#endif /* SRC_HAL_RGB_LED_HEADER_RGBLED_CONFIG_H_ */
