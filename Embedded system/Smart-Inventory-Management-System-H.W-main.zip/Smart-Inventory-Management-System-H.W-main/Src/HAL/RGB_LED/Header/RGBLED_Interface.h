/*
 * ============================================================================================================*
 * Author      : Alaa Emad
 * Module name : RGB_LED
 * File name   : RGBLED_Interface.h
 * Version     : V1.0.0
 * Date        : Feb 12 2025
 * Description : Prototypes and other files are included here
 ============================================================================================================
*/

#ifndef SRC_HAL_RGB_LED_HEADER_RGBLED_INTERFACE_H_
#define SRC_HAL_RGB_LED_HEADER_RGBLED_INTERFACE_H_

#include "../../../Lib/BitMath.h"
#include "../../../Lib/Definition.h"
#include "../../../Lib/StdType.h"

#include "RGBLED_Private.h"
#include "RGBLED_Config.h"
#include "RGBLED_Register.h"

/*Init for all RGB LED*/
void RGB_LED_Init(uint_8 LED_Number);

/*Turn on the led with the required color*/
void RGB_LED_ON(uint_8 LED_Number , uint_8 LED_Color);

/*Turn off all the leds*/
void RGB_LED_OFF(uint_8 LED_Number);

#endif /* SRC_HAL_RGB_LED_HEADER_RGBLED_INTERFACE_H_ */
