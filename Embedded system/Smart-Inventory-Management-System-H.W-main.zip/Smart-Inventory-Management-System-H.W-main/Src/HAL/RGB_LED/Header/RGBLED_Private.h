/*
 * ============================================================================================================*
 * Author      : Alaa Emad
 * Module name : RGB_LED
 * File name   : RGBLED_Private.h
 * Version     : V1.0.0
 * Date        : Feb 12 2025
 * Description : Adding some definitions can't be modified
 ============================================================================================================
*/

#ifndef SRC_HAL_RGB_LED_HEADER_RGBLED_PRIVATE_H_
#define SRC_HAL_RGB_LED_HEADER_RGBLED_PRIVATE_H_

#define Num_LEDS	6

#define LED1	1
#define LED2	2
#define LED3	3
#define LED4	4
#define LED5	5
#define LED6	6

typedef enum
{
  RED,
  GREEN
}LED_Color;

#endif /* SRC_HAL_RGB_LED_HEADER_RGBLED_PRIVATE_H_ */
