/*
 * ============================================================================================================*
 * Author      : Alaa Emad
 * Module name : RGB_LED
 * File name   : RGBLED_Register.h
 * Version     : V1.0.0
 * Date        : Feb 12 2025
 * Description : Definition of the registers and there address
 ============================================================================================================
*/

#ifndef SRC_HAL_RGB_LED_HEADER_RGBLED_REGISTER_H_
#define SRC_HAL_RGB_LED_HEADER_RGBLED_REGISTER_H_



#endif /* SRC_HAL_RGB_LED_HEADER_RGBLED_REGISTER_H_ */
