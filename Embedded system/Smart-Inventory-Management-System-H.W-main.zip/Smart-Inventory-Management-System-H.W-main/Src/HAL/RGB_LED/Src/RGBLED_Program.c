/*
 * ============================================================================================================*
 * Author      : Alaa Emad
 * Module name : RGB_LED
 * File name   : RGBLED_Program.c
 * Version     : V1.0.0
 * Date        : Feb 12 2025
 * Description : Implementation of the functions are here
 ============================================================================================================
*/

#include "../../../MCAL/DIO/Header/DIO_Interface.h"
#include "../Header/RGBLED_Interface.h"

void RGB_LED_Init(uint_8 LED_Number)
{
	if(LED_Number >= LED1 && LED_Number <= LED6)
	{
		switch(LED_Number)
		{
			case LED1: DIO_SelectDirectionForPin(RGB_LED1_Group,RGB_LED1_RED,Output);
					   DIO_SelectDirectionForPin(RGB_LED1_Group,RGB_LED1_Green,Output);
					   break;
			case LED2: DIO_SelectDirectionForPin(RGB_LED2_Group,RGB_LED2_RED,Output);
					   DIO_SelectDirectionForPin(RGB_LED2_Group,RGB_LED2_Green,Output);
					   break;
			case LED3: DIO_SelectDirectionForPin(RGB_LED3_Group,RGB_LED3_RED,Output);
					   DIO_SelectDirectionForPin(RGB_LED3_Group,RGB_LED3_Green,Output);
					   break;
			case LED4: DIO_SelectDirectionForPin(RGB_LED4_Group,RGB_LED4_RED,Output);
					   DIO_SelectDirectionForPin(RGB_LED4_Group,RGB_LED4_Green,Output);
					   break;
			case LED5: DIO_SelectDirectionForPin(RGB_LED5_Group,RGB_LED5_RED,Output);
					   DIO_SelectDirectionForPin(RGB_LED5_Group,RGB_LED5_Green,Output);
					   break;
			case LED6: DIO_SelectDirectionForPin(RGB_LED6_Group,RGB_LED6_RED,Output);
					   DIO_SelectDirectionForPin(RGB_LED6_Group,RGB_LED6_Green,Output);
					   break;
			default: /*Invalid LED Number*/ break;
		}
	}
	else
	{
		/*Invalid LED Number*/
	}
}

void RGB_LED_ON(uint_8 LED_Number , uint_8 LED_Color)
{
	if(LED_Number >= LED1 && LED_Number <= LED6 && LED_Color >= RED && LED_Color <= GREEN)
	{
		switch(LED_Number)
		{
			case LED1:
				if(LED_Color == RED)
				{
					DIO_SelectOutputValueForPin(RGB_LED1_Group,RGB_LED1_Green,Low);
					DIO_SelectOutputValueForPin(RGB_LED1_Group,RGB_LED1_RED,High);
				}
				else if(LED_Color == GREEN)
				{
					DIO_SelectOutputValueForPin(RGB_LED1_Group,RGB_LED1_RED,Low);
					DIO_SelectOutputValueForPin(RGB_LED1_Group,RGB_LED1_Green,High);
				}
				else
				{
					/*Error State*/
				}
				break;
			case LED2:
				if(LED_Color == RED)
				{
					DIO_SelectOutputValueForPin(RGB_LED2_Group,RGB_LED2_Green,Low);
					DIO_SelectOutputValueForPin(RGB_LED2_Group,RGB_LED2_RED,High);
				}
				else if(LED_Color == GREEN)
				{
					DIO_SelectOutputValueForPin(RGB_LED2_Group,RGB_LED2_RED,Low);
					DIO_SelectOutputValueForPin(RGB_LED2_Group,RGB_LED2_Green,High);
				}
				else
				{
					/*Error State*/
				}
				break;
			case LED3:
				if(LED_Color == RED)
				{
					DIO_SelectOutputValueForPin(RGB_LED3_Group,RGB_LED3_Green,Low);
					DIO_SelectOutputValueForPin(RGB_LED3_Group,RGB_LED3_RED,High);
				}
				else if(LED_Color == GREEN)
				{
					DIO_SelectOutputValueForPin(RGB_LED3_Group,RGB_LED3_RED,Low);
					DIO_SelectOutputValueForPin(RGB_LED3_Group,RGB_LED3_Green,High);
				}
				else
				{
					/*Error State*/
				}
				break;
			case LED4:
				if(LED_Color == RED)
				{
					DIO_SelectOutputValueForPin(RGB_LED4_Group,RGB_LED4_Green,Low);
					DIO_SelectOutputValueForPin(RGB_LED4_Group,RGB_LED4_RED,High);
				}
				else if(LED_Color == GREEN)
				{
					DIO_SelectOutputValueForPin(RGB_LED4_Group,RGB_LED4_RED,Low);
					DIO_SelectOutputValueForPin(RGB_LED4_Group,RGB_LED4_Green,High);
				}
				else
				{
					/*Error State*/
				}
				break;
			case LED5:
				if(LED_Color == RED)
				{
					DIO_SelectOutputValueForPin(RGB_LED5_Group,RGB_LED5_Green,Low);
					DIO_SelectOutputValueForPin(RGB_LED5_Group,RGB_LED5_RED,High);
				}
				else if(LED_Color == GREEN)
				{
					DIO_SelectOutputValueForPin(RGB_LED5_Group,RGB_LED5_RED,Low);
					DIO_SelectOutputValueForPin(RGB_LED5_Group,RGB_LED5_Green,High);
				}
				else
				{
					/*Error State*/
				}
				break;
			case LED6:
				if(LED_Color == RED)
				{
					DIO_SelectOutputValueForPin(RGB_LED6_Group,RGB_LED6_Green,Low);
					DIO_SelectOutputValueForPin(RGB_LED6_Group,RGB_LED6_RED,High);
				}
				else if(LED_Color == GREEN)
				{
					DIO_SelectOutputValueForPin(RGB_LED6_Group,RGB_LED6_RED,Low);
					DIO_SelectOutputValueForPin(RGB_LED6_Group,RGB_LED6_Green,High);
				}
				else
				{
					/*Error State*/
				}
				break;
			default: /*Error State*/ break;
		}
	}
	else
	{
		/*Invalid LED Number or LED Color*/
	}
}

void RGB_LED_OFF(uint_8 LED_Number)
{
	if(LED_Number >= LED1 && LED_Number <= LED6)
	{
		switch(LED_Number)
		{
			case LED1: DIO_SelectOutputValueForPin(RGB_LED1_Group,RGB_LED1_RED,Low);
					   DIO_SelectOutputValueForPin(RGB_LED1_Group,RGB_LED1_Green,Low);
					   break;
			case LED2: DIO_SelectOutputValueForPin(RGB_LED2_Group,RGB_LED2_RED,Low);
					   DIO_SelectOutputValueForPin(RGB_LED2_Group,RGB_LED2_Green,Low);
					   break;
			case LED3: DIO_SelectOutputValueForPin(RGB_LED3_Group,RGB_LED3_RED,Low);
					   DIO_SelectOutputValueForPin(RGB_LED3_Group,RGB_LED3_Green,Low);
					   break;
			case LED4: DIO_SelectOutputValueForPin(RGB_LED4_Group,RGB_LED4_RED,Low);
					   DIO_SelectOutputValueForPin(RGB_LED4_Group,RGB_LED4_Green,Low);
					   break;
			case LED5: DIO_SelectOutputValueForPin(RGB_LED5_Group,RGB_LED5_RED,Low);
					   DIO_SelectOutputValueForPin(RGB_LED5_Group,RGB_LED5_Green,Low);
					   break;
			case LED6: DIO_SelectOutputValueForPin(RGB_LED6_Group,RGB_LED6_RED,Low);
					   DIO_SelectOutputValueForPin(RGB_LED6_Group,RGB_LED6_Green,Low);
					   break;
			default: /*Invalid LED Number*/ break;
		}
	}
	else
	{
		/*Invalid LED Number*/
	}
}
