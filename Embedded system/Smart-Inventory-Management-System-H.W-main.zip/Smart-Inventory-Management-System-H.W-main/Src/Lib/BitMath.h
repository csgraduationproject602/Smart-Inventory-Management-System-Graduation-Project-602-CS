/*
 * ============================================================================================================*
 * Author      : Alaa Emad
 * Module name : ---
 * File name   : BitMath.h
 * Version     : V1.0.0
 * Date        : Dec 20 2024
 * Description : Some bit math functions will be used in the project
 ============================================================================================================
*/

#ifndef SRC_LIB_BITMATH_H_
#define SRC_LIB_BITMATH_H_

#define SetBit(Reg, BitNum) (Reg)|=((1) << (BitNum))
#define ClrBit(Reg, BitNum) (Reg)&=~((1) << (BitNum))
#define TogBit(Reg, BitNum) (Reg)^=((1) << (BitNum))
#define GetBit(Reg, BitNum) (((Reg) >> (BitNum)) & (0x01))

#endif /* SRC_LIB_BITMATH_H_ */
