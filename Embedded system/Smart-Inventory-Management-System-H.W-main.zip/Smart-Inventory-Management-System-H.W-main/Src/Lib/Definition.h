/*
 * ============================================================================================================*
 * Author      : Alaa Emad
 * Module name : ---
 * File name   : Definition.h
 * Version     : V1.0.0
 * Date        : Dec 20 2024
 * Description : Some Macros will be used in the project
 ============================================================================================================
*/

#ifndef SRC_LIB_DEFINITION_H_
#define SRC_LIB_DEFINITION_H_

#define Null     ((void*)0)
#define NULL     ((void*)0)
#define null     ((void*)0)
#define NullChar '\0'
/*---------------------------------*/
#define Input    0
#define Output   1
/*---------------------------------*/
#define Low      0
#define High     1
/*---------------------------------*/
#define Off      0
#define On       1
/*---------------------------------*/
#define Disable  0
#define Enable   1
#define AllEnable  0xFF
#define AllDisable 0x00
/*---------------------------------*/
#define Pressed 0
#define NotPressed 1
/*---------------------------------*/

#endif /* SRC_LIB_DEFINITION_H_ */
