/*
 * ============================================================================================================*
 * Author      : Alaa Emad
 * Module name : ---
 * File name   : StdType.h
 * Version	   : V1.0.0
 * Date        : Dec 20 2024
 * Description : Some std type for data types will be used in the project
 ============================================================================================================
*/

#ifndef SRC_LIB_STDTYPE_H_
#define SRC_LIB_STDTYPE_H_

typedef unsigned char uint_8;
typedef   signed char sint_8;

typedef unsigned short int uint_16;
typedef   signed short int sint_16;

typedef unsigned long int uint_32;
typedef   signed long int sint_32;

typedef unsigned long long int uint_64;
typedef   signed long long int sint_64;

typedef float   f_32;
typedef double  f_64;
typedef long double f_128;

#endif /* SRC_LIB_STDTYPE_H_ */
