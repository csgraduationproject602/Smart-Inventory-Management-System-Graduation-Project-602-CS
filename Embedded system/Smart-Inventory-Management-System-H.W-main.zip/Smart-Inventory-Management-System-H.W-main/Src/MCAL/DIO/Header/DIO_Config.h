/*
 * ============================================================================================================*
 * Author      : Martina Safwat Lito
 * Module name : DIO
 * File name   : DIO_Config.h
 * Version     : V1.0.0
 * Date        : Dec 21 2024
 * Description : Contains configuration definitions for setting up microcontroller pins and ports
 ============================================================================================================
*/

#ifndef MCAL_DIO_HEADER_DIO_CONFIG_H_
#define MCAL_DIO_HEADER_DIO_CONFIG_H_



#endif /* MCAL_DIO_HEADER_DIO_CONFIG_H_ */
