/*
 * ============================================================================================================*
 * Author      : Martina Safwat Lito
 * Module name : DIO
 * File name   : DIO_Interface.h
 * Version     : V1.0.0
 * Date        : Dec 21 2024
 * Description : Contains function prototypes for configuring and controlling microcontroller pins and ports
 ============================================================================================================
*/

#ifndef MCAL_DIO_HEADER_DIO_INTERFACE_H_
#define MCAL_DIO_HEADER_DIO_INTERFACE_H_

#include "../../../Lib/BitMath.h"
#include "../../../Lib/Definition.h"
#include "../../../Lib/StdType.h"

#include "DIO_Register.h"
#include "DIO_Private.h"
#include "DIO_Config.h"

void DIO_SelectDirectionForPin(uint_8 GroupName, uint_8 PinNumber, uint_8 DirectionState);
void DIO_SelectOutputValueForPin(uint_8 GroupName, uint_8 PinNumber, uint_8 Outputvalue);
void DIO_ReadInputValueForPin(uint_8 GroupName, uint_8 PinNumber, uint_8 * InputValue);

void DIO_SelectDirectionForGroup(uint_8 GroupName, uint_8 DirectionState);
void DIO_SelectOutputValueForGroup(uint_8 GroupName, uint_8 Outputvalue);
void DIO_ReadInputValueForGroup(uint_8 GroupName, uint_8 * InputValue);

void DIO_ControlInternalPullUpForPin(uint_8 GroupName, uint_8 PinNumber, uint_8 State);
void DIO_ToggelValueForGroup(uint_8 GroupName);
void DIO_ToggelValueForPin(uint_8 GroupName, uint_8 PinNumber);

#endif /* MCAL_DIO_HEADER_DIO_INTERFACE_H_ */
