/*
 * ============================================================================================================*
 * Author      : Martina Safwat Lito
 * Module name : DIO
 * File name   : DIO_Private.h
 * Version     : V1.0.0
 * Date        : Dec 21 2024
 * Description : Contains private macros and definitions for the DIO module to manage hardware registers and internal configurations
 ============================================================================================================
*/

#ifndef MCAL_DIO_HEADER_DIO_PRIVATE_H_
#define MCAL_DIO_HEADER_DIO_PRIVATE_H_

#define GroupA 1
#define GroupB 2
#define GroupC 3
#define GroupD 4

#define Pin0 0
#define Pin1 1
#define Pin2 2
#define Pin3 3
#define Pin4 4
#define Pin5 5
#define Pin6 6
#define Pin7 7

#endif /* MCAL_DIO_HEADER_DIO_PRIVATE_H_ */
