/*
 * ============================================================================================================*
 * Author      : Martina Safwat Lito
 * Module name : DIO
 * File name   : DIO_Register.h
 * Version     : V1.0.0
 * Date        : Dec 21 2024
 * Description : Define of each register and its address of DIO included in this file
 ============================================================================================================
*/

#ifndef MCAL_DIO_HEADER_DIO_REGISTER_H_
#define MCAL_DIO_HEADER_DIO_REGISTER_H_

/*Registers A*/
#define DIO_DDRA *((volatile uint_8*)0x3A)
#define DIO_PORTA *((volatile uint_8*)0x3B)
#define DIO_PINA *((volatile uint_8*)0x39)

/*Registers B*/
#define DIO_DDRB *((volatile uint_8*)0x37)
#define DIO_PORTB *((volatile uint_8*)0x38)
#define DIO_PINB *((volatile uint_8*)0x36)

/*Registers C*/
#define DIO_DDRC *((volatile uint_8*)0x34)
#define DIO_PORTC *((volatile uint_8*)0x35)
#define DIO_PINC *((volatile uint_8*)0x33)

/*Registers D*/
#define DIO_DDRD *((volatile uint_8*)0x31)
#define DIO_PORTD *((volatile uint_8*)0x32)
#define DIO_PIND *((volatile uint_8*)0x30)

#endif /* MCAL_DIO_HEADER_DIO_REGISTER_H_ */
