/*
 * ============================================================================================================*
 * Author      : Alaa Emad
 * Module name : EXTI
 * File name   : EXTI_Config.h
 * Version     : V1.0.0
 * Date        : Jan 28 2025
 * Description : Adding some definitions can be modified
 ============================================================================================================
*/

#ifndef MCAL_EXTI_HEADER_EXTI_CONFIG_H_
#define MCAL_EXTI_HEADER_EXTI_CONFIG_H_

/*1- LowLevel
 *2-AnyLogic
 *3-FallingEdge
 *4-RisingEdge
 */
#define EXTI0_SensType	FallingEdge

/*1- LowLevel
 *2-AnyLogic
 *3-FallingEdge
 *4-RisingEdge
 */
#define EXTI1_SensType	FallingEdge

/*1-FallingEdge
 *2-RisingEdge
 */
#define EXTI2_SensType	FallingEdge

#endif /* MCAL_EXTI_HEADER_EXTI_CONFIG_H_ */
