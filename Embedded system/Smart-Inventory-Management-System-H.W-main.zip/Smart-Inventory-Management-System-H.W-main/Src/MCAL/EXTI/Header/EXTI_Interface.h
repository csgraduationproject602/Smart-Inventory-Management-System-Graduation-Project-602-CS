/*
 * ============================================================================================================*
 * Author      : Alaa Emad
 * Module name : EXTI
 * File name   : EXTI_Interface.h
 * Version     : V1.0.0
 * Date        : Jan 28 2025
 * Description : Prototypes and other files are included here
 ============================================================================================================
*/

#ifndef MCAL_EXTI_HEADER_EXTI_INTERFACE_H_
#define MCAL_EXTI_HEADER_EXTI_INTERFACE_H_

#include "../../../Lib/BitMath.h"
#include "../../../Lib/Definition.h"
#include "../../../Lib/StdType.h"

#include "EXTI_Register.h"
#include "EXTI_Private.h"
#include "EXTI_Config.h"

//Post Configuration
void EXTI0_Init(uint_8 SensType);

//Post Configuration
void EXTI1_Init(uint_8 SensType);

//Post Configuration
void EXTI2_Init(uint_8 SensType);

#endif /* MCAL_EXTI_HEADER_EXTI_INTERFACE_H_ */
