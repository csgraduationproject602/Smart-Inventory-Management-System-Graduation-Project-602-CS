/*
 * ============================================================================================================*
 * Author      : Alaa Emad
 * Module name : EXTI
 * File name   : EXTI_Register.h
 * Version     : V1.0.0
 * Date        : Jan 28 2025
 * Description : Definition of the registers and there address
 ============================================================================================================
*/

#ifndef MCAL_EXTI_HEADER_EXTI_REGISTER_H_
#define MCAL_EXTI_HEADER_EXTI_REGISTER_H_

/*MCUCR*/
#define EXTI_MCUCR *((volatile uint_8*)0x55)

/*MCUCSR*/
#define EXTI_MCUCSR *((volatile uint_8*)0x54)

/*GICR*/
#define EXTI_GICR *((volatile uint_8*)0x5B)

/*GIFR*/
#define EXTI_GIFR *((volatile uint_8*)0x5A)

#endif /* MCAL_EXTI_HEADER_EXTI_REGISTER_H_ */
