/*
 * ============================================================================================================*
 * Author      : Alaa Emad
 * Module name : GIE
 * File name   : GIE_Config.h
 * Version     : V1.0.0
 * Date        : Dec 21 2024
 * Description : Adding some definitions can be modified
 ============================================================================================================
*/

#ifndef MCAL_GIE_HEADER_GIE_CONFIG_H_
#define MCAL_GIE_HEADER_GIE_CONFIG_H_



#endif /* MCAL_GIE_HEADER_GIE_CONFIG_H_ */
