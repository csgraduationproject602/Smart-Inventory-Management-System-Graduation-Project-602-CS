/*
 * ============================================================================================================*
 * Author      : Alaa Emad
 * Module name : GIE
 * File name   : GIE_Interface.h
 * Version     : V1.0.0
 * Date        : Dec 21 2024
 * Description : Prototypes and other files are included here
 ============================================================================================================
*/

#ifndef MCAL_GIE_HEADER_GIE_INTERFACE_H_
#define MCAL_GIE_HEADER_GIE_INTERFACE_H_

#include "../../../Lib/BitMath.h"
#include "../../../Lib/Definition.h"
#include "../../../Lib/StdType.h"

#include "GIE_Register.h"
#include "GIE_Private.h"
#include "GIE_Config.h"

void GIE_Enable();
void GIE_Disable();

#endif /* MCAL_GIE_HEADER_GIE_INTERFACE_H_ */
