/*
 * ============================================================================================================*
 * Author      : Alaa Emad
 * Module name : GIE
 * File name   : GIE_Private.h
 * Version     : V1.0.0
 * Date        : Dec 21 2024
 * Description : Adding some definitions can't be modified
 ============================================================================================================
*/

#ifndef MCAL_GIE_HEADER_GIE_PRIVATE_H_
#define MCAL_GIE_HEADER_GIE_PRIVATE_H_

#define GIE_I 7

#endif /* MCAL_GIE_HEADER_GIE_PRIVATE_H_ */
