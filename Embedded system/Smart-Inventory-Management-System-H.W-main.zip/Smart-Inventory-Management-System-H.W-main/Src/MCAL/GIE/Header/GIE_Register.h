/*
 * ============================================================================================================*
 * Author      : Alaa Emad
 * Module name : GIE
 * File name   : GIE_Register.h
 * Version     : V1.0.0
 * Date        : Dec 21 2024
 * Description : Definition of the registers and there address
 ============================================================================================================
*/

#ifndef MCAL_GIE_HEADER_GIE_REGISTER_H_
#define MCAL_GIE_HEADER_GIE_REGISTER_H_

#define GIE_SREG *((volatile uint_8*)0x5F)

#endif /* MCAL_GIE_HEADER_GIE_REGISTER_H_ */
