/*
 * ============================================================================================================*
 * Author      : Alaa Emad
 * Module name : GIE
 * File name   : GIE_Program.c
 * Version     : V1.0.0
 * Date        : Dec 21 2024
 * Description : Implementation of the functions are here
 ============================================================================================================
*/

#include "../Header/GIE_Interface.h"

void GIE_Enable()
{
	SetBit(GIE_SREG,GIE_I);
}

void GIE_Disable()
{
	ClrBit(GIE_SREG,GIE_I);
}
