/*
 * ============================================================================================================*
 * Author      : Alaa Emad
 * Module name : Timer0
 * File name   : Timer0_Config.h
 * Version     : V1.0.0
 * Date        : Mar 4 2025
 * Description : Adding some definitions can be modified
 ============================================================================================================
*/

#ifndef SRC_MCAL_TIMER0_HEADER_TIMER0_CONFIG_H_
#define SRC_MCAL_TIMER0_HEADER_TIMER0_CONFIG_H_

/*Clock Select
 * T0_Stoped,
T0_Prescaller1,
T0_Prescaller8,
T0_Prescaller64,
T0_Prescaller256,
T0_Prescaller1024,
T0_ExternalFalling,
T0_ExternalRising,
*/
#define ClockSelectInit  T0_Prescaller8

#define PreloadValueInit    255

#define NumberOfOvfCount    9765

#endif /* SRC_MCAL_TIMER0_HEADER_TIMER0_CONFIG_H_ */
