/*
 * ============================================================================================================*
 * Author      : Alaa Emad
 * Module name : Timer0
 * File name   : Timer0_Interface.h
 * Version     : V1.0.0
 * Date        : Mar 4 2025
 * Description : Prototypes and other files are included here
 ============================================================================================================
*/

#ifndef SRC_MCAL_TIMER0_HEADER_TIMER0_INTERFACE_H_
#define SRC_MCAL_TIMER0_HEADER_TIMER0_INTERFACE_H_

#include "../../../Lib/BitMath.h"
#include "../../../Lib/Definition.h"
#include "../../../Lib/StdType.h"

#include "Timer0_Register.h"
#include "Timer0_Private.h"
#include "Timer0_Config.h"

void T0_NormalModeInit();
void T0_ChangeClockSelect(uint_8 ClockSelect);
void T0_ControlInterruptState(uint_8 InterruptType , uint_8 State);
void T0_DisableTimer();
void T0_ChangePreloadValue(uint_8 PreloadValue);

void T0_CallBackFunctionNormalMode(void(*PF)(void));
void __vector_11(void) __attribute__((signal));

#endif /* SRC_MCAL_TIMER0_HEADER_TIMER0_INTERFACE_H_ */
