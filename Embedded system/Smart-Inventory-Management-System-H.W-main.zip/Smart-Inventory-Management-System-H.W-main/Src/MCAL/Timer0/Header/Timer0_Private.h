/*
 * ============================================================================================================*
 * Author      : Alaa Emad
 * Module name : Timer0
 * File name   : Timer0_Private.h
 * Version     : V1.0.0
 * Date        : Mar 4 2025
 * Description : Adding some definitions can't be modified
 ============================================================================================================
*/

#ifndef SRC_MCAL_TIMER0_HEADER_TIMER0_PRIVATE_H_
#define SRC_MCAL_TIMER0_HEADER_TIMER0_PRIVATE_H_

/*General Pin */
#define T0_CS02  2
#define T0_CS01  1
#define T0_CS00  0

/*Pin for Normal Mode*/
#define T0_WGM01   3
#define T0_WGM00   6
#define T0_TOIE0   0
#define T0_TOV0    0

typedef enum
{
	T0_Stoped = 0,
	T0_Prescaller1 = 1,
	T0_Prescaller8 = 2,
	T0_Prescaller64 = 3,
	T0_Prescaller256 = 4,
	T0_Prescaller1024 = 5,
	T0_ExternalFalling = 6,
	T0_ExternalRising = 7,
}ClockSelect;

/*Interrupt Type*/
#define OverFlowModeInterrupt	0

#endif /* SRC_MCAL_TIMER0_HEADER_TIMER0_PRIVATE_H_ */
