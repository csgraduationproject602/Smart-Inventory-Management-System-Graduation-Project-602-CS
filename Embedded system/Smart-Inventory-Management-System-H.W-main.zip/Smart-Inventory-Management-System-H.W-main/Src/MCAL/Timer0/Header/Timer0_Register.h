/*
 * ============================================================================================================*
 * Author      : Alaa Emad
 * Module name : Timer0
 * File name   : Timer0_Register.h
 * Version     : V1.0.0
 * Date        : Mar 4 2025
 * Description : Definition of the registers and there address
 ============================================================================================================
*/

#ifndef SRC_MCAL_TIMER0_HEADER_TIMER0_REGISTER_H_
#define SRC_MCAL_TIMER0_HEADER_TIMER0_REGISTER_H_

#define T0_TCCR0 *((volatile uint_8*)0x53)
#define T0_TCNT0 *((volatile uint_8*)0x52)
#define T0_TIMSK *((volatile uint_8*)0x59)
#define T0_TIFR  *((volatile uint_8*)0x58)
#define T0_OCR0  *((volatile uint_8*)0x5C)

#endif /* SRC_MCAL_TIMER0_HEADER_TIMER0_REGISTER_H_ */
