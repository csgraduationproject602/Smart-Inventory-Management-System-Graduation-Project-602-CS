/*
 * ============================================================================================================*
 * Author      : Alaa Emad
 * Module name : Timer0
 * File name   : Timer0_Program.c
 * Version     : V1.0.0
 * Date        : Mar 4 2025
 * Description : Implementation of the functions are here
 ============================================================================================================
*/

#include "../Header/Timer0_Interface.h"

static uint_8 PreloadValueGlobal = PreloadValueInit;
static uint_32 NoOfOVFCountGlobal = NumberOfOvfCount;
static uint_8 TCCR0Wrraper = 0;
static void (*GlobalPF)(void) = NULL;

void T0_NormalModeInit()
{
	//Select Mode Normal Mode
	ClrBit(T0_TCCR0,T0_WGM00);
	ClrBit(T0_TCCR0,T0_WGM01);

	//Update Timer Register PreloadValue
	T0_ChangePreloadValue(PreloadValueGlobal);

	//Enable OVF Interrupt
	T0_ControlInterruptState(OverFlowModeInterrupt,Enable);

	//Select Clock Select
	T0_ChangeClockSelect(ClockSelectInit);
}

void T0_ChangePreloadValue(uint_8 PreloadValue)
{
	if(PreloadValue != PreloadValueGlobal)
	{
		PreloadValueGlobal = PreloadValue;
	}
	T0_TCNT0 = PreloadValueGlobal;
}

void T0_ChangeClockSelect(uint_8 ClockSelect)
{
	if(ClockSelect >= T0_Prescaller1 && ClockSelect <= T0_ExternalRising)
	{
		T0_TCCR0 &= 0b11111000;
		T0_TCCR0 |= ClockSelect;
		/*--------------------------------*/
		TCCR0Wrraper &= 0b11111000;
		TCCR0Wrraper |= ClockSelect;
	}
}

void T0_ControlInterruptState(uint_8 InterruptType , uint_8 State)
{
	if(InterruptType == OverFlowModeInterrupt && State == Enable)
	{
		SetBit(T0_TIMSK,T0_TOIE0);
	}
	else if(InterruptType == OverFlowModeInterrupt && State == Disable)
	{
		ClrBit(T0_TIMSK,T0_TOIE0);
	}
	else
	{

	}
}

void T0_DisableTimer()
{
	T0_TCCR0 = T0_Stoped;
}

void __vector_11(void)
{
	static uint_32 counter = 0;
	counter++;
	if(counter == NoOfOVFCountGlobal)
	{
		//Action
		GlobalPF();

		T0_ChangePreloadValue(PreloadValueGlobal);
		counter = 0;
	}
}

void T0_CallBackFunctionNormalMode(void(*PF)(void))
{
	if(PF != NULL)
	{
		GlobalPF = PF;
	}
}
