/*
 * ============================================================================================================*
 * Author      : Alaa Emad
 * Module name : USART
 * File name   : USART_Config.h
 * Version     : V1.0.0
 * Date        : Jan 4 2025
 * Description : Adding some definitions can be modified
 ============================================================================================================
*/

#ifndef MCAL_USART_HEADER_USART_CONFIG_H_
#define MCAL_USART_HEADER_USART_CONFIG_H_

#define RXInterruptStateInit	Disable

#define TXInterruptStateInit	Disable

#define UDRInterruptStateInit	Disable

/*
 * RxType
 * TxType
 * Both
 * */
#define CommunicationTypeInit Both

/*
 * 	USART_Asynch,
 * 	USART_Synch
 * 	*/
#define OperationMode	USART_Asynch

/*
 * 	_1Bit,
 * 	_2Bit
 * */

#define StopMode	_1Bit

/*
 * 	Parity_Disable = 0,
 * 	Reserved = 32,
 * 	Parity_Even = 64,
 * 	Parity_Odd = 96
 * 	*/
#define ParityMode	Parity_Disable

/*
 * 	_5BitData,
 * 	_6BitData,
 * 	_7BitData,
 * 	_8BitData,
 * 	_9BitData
 * 	*/
#define CharSizeInit	_8BitData

#define TimeOut	500

#endif /* MCAL_USART_HEADER_USART_CONFIG_H_ */
