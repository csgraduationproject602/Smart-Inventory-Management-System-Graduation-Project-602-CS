/*
 * ============================================================================================================*
 * Author      : Alaa Emad
 * Module name : USART
 * File name   : USART_Interface.h
 * Version     : V1.0.0
 * Date        : Jan 4 2025
 * Description : Prototypes and other files are included here
 ============================================================================================================
*/

#ifndef MCAL_USART_HEADER_USART_INTERFACE_H_
#define MCAL_USART_HEADER_USART_INTERFACE_H_

#include "../../../Lib/BitMath.h"
#include "../../../Lib/Definition.h"
#include "../../../Lib/StdType.h"

#include "USART_Register.h"
#include "USART_Private.h"
#include "USART_Config.h"

/*Global Functions*/
void USART_ControlInterrupt(uint_8 InterruptType , uint_8 State);

/*USART Functions*/
void USART_Init();

void USART_RxChar(uint_8 * Data);

void USART_TxChar(uint_8 Data);



#endif /* MCAL_USART_HEADER_USART_INTERFACE_H_ */
