/*
 * ============================================================================================================*
 * Author      : Alaa Emad
 * Module name : Smart Inventory Management System
 * File name   : main.c
 * Version     : V1.0.0
 * Date        : Feb 12 2025
 * Description : The core of the project and the start of execution provided here
 ============================================================================================================
*/

/*Including the SIMS_Interface.h file*/
#include "App/Smart_IMS/Header/SIMS_Interface.h"

/*Define the main function*/
int main()
{
	/*Initialize the System*/
	SystemInit();

	/*Run The System*/
	SystemRunning();

	return 0;
}
