export interface Office {
    name: string;
    location?: string;
  }
  
  export interface OfficeForCreationDto {
    name: string;
    location?: string;
  }