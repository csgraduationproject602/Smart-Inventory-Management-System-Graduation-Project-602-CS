export class Shelfs {
  id: string;
  name: string;
  isAvailable: boolean;
  warehouse_Id: string;
  categoryId: string;
  warehouseName: string;
}
