export interface Supplier {
    id?: string; 
    name: string;
    contactInfo?: string; 
  }
  
