export interface Warehouse {
  Id: string;
  name: string;
  location: string;
  capacity: number;
}
