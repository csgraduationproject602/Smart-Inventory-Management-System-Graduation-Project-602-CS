export interface ForgotPasswordDto {
    email: string;
    clientURI: string;
}