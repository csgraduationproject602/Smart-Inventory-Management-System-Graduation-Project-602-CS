export interface Role {
    id: string;
    name: string;
    dateCreated: Date;
  }


  