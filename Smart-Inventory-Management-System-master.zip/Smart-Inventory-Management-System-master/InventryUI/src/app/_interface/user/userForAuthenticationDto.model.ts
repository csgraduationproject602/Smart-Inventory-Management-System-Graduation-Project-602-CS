export interface UserForAuthenticationDto {
    email: string;
    password: string;
    clientURI: string;
}