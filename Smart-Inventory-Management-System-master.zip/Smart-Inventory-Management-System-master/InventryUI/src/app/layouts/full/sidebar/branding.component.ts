import { Component } from '@angular/core';

@Component({
  selector: 'app-branding',
  template: `
    <div class="branding">
 <h4 style="color: rgb(55, 43, 226);">Inventory Management System</h4>
    </div>
  `,
})
export class BrandingComponent {
  constructor() {}
}
