export const environment = {
  production: false,
  apiUrl: 'http://sims.runasp.net',
  clientUrl: 'http://localhost:4200',
};
