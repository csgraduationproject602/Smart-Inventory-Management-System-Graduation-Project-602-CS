export const environment = {
  production: true,
  apiUrl: '',
  clientUrl: 'https://localhost:5001',
};
