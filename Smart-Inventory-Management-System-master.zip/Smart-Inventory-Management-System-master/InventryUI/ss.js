let class ='dd';
console.log(class)